v0.1.2 -- August 21, 2013
--------------------------

Minor update for proper [Bower] and [Component] support.

 * Add Bower support.
 * Fix Component support and use `component/jquery` as a dependency.

v0.1.1 -- August 21, 2013
-------------------------

Minor fixes.

 * Removed the busy cursor that occurs when loading.
 * Added support for IE7 to IE9. (#3, [Mark Bao])
 * Implement `trickleRate` and `trickleSpeed` options.
 * Implement the `showSpinner` option to allow removing the spinner. (#5, #9, 
     [Rahul C S])
 * Registered as a Component in Component.io.
 * Updated the Readme with better Turbolinks instructions. (#8)

v0.1.0 -- August 20, 2013
-------------------------

Initial release.

[Rahul C S]: https://github.com/rahulcs
[Mark Bao]: https://github.com/markbao
[Bower]: http://bower.io
[Component]: http://component.io
